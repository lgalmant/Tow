package aStar.utils;

public class Logger {
        public void addToLog(String s) {
                System.out.println(s);
        }
}