package contenu;

import com.badlogic.gdx.math.Rectangle;

public interface Constantes {
	
	 public final static int NBCOL = 19;
     
     public final static int NBLIG = 10;
     
     public final static int NBCOLM = 5;
     
     public final static int NBLIGM = 5;
     
     public final static int CEP = 40;
     
     public final static Rectangle recS=new Rectangle(0,0,CEP,CEP);
     
     public final static int TM = 25;
     
     public final static int L = 1200;
     
     public final static int H = 700;

}
