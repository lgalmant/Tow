package contenu;

public class Settings {
	
	public static boolean autoriserSon=true;
	public static String nom;

}
